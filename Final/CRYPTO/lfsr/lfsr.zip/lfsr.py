import hashlib
from Crypto.Util.number import *
from secret import flag

class LFSR:
    def __init__(self, n, seed, mask):
        self.state = [int(b) for b in f"{seed:0{n}b}"]
        self.mask_bits = [int(b) for b in f"{mask:0{n}b}"]
        self.n = n

    def __call__(self):
        s = sum([self.state[i] * self.mask_bits[i] for i in range(self.n)]) & 1
        self.state = self.state[1:] + [s]
        return self.state[-1] ^ int(hashlib.sha256(str(self.state[-1]).encode()).hexdigest(), 16) & 1

mask = getRandomNBitInteger(128)
seed = getRandomNBitInteger(128)
lfsr = LFSR(128, seed, mask)
assert flag == 'ZSCTF{' + hashlib.md5(str(seed).encode()).hexdigest() + '}'
out = sum((lfsr() << (127 - i)) for i in range(128))
print(mask)
print(out)
# 256145588589325975889797077785006635585
# 161012175678781152374518992864407311111