import hashlib
from Crypto.Util.number import *
from secret import flag

class LFSR:
    def __init__(self, n, seed, mask):
        self.state = [int(b) for b in f"{seed:0{n}b}"]
        self.mask_bits = [int(b) for b in f"{mask:0{n}b}"]
        self.n = n
        self.noise = [int(b) for b in bin(int(hashlib.md5(str(self.state).encode()).hexdigest(), 16))[2:].zfill(128)]

    def update(self):
        s = sum([self.state[i] * self.mask_bits[i] for i in range(self.n)]) & 1
        self.state = self.state[1:] + [s]
        return self.state[-1]
    
    def __call__(self, n):
        out = 0
        for _ in range(n):
            out += self.update() ^ self.noise[_ % 128]
            out <<= 1
        return out

mask = getRandomNBitInteger(128)
seed = getRandomNBitInteger(128)
lfsr = LFSR(128, seed, mask)
assert flag == 'ZSCTF{' + hashlib.md5(str(seed).encode()).hexdigest() + '}'
print(mask)
print(lfsr(270))
# 201405118877933076220190540329663957308
# 3012364434768591887448754388178485244043747024578848630153660637575862658251786506